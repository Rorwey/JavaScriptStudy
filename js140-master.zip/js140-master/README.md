# js140
本仓库存放尚硅谷李立超老师的 JavaScript 视频代码和笔记。
