<template>
  <div>
    <h1>这是 App 组件</h1>
  </div>
</template>

<script>
</script>


<style lang="scss" scoped>

</style>
