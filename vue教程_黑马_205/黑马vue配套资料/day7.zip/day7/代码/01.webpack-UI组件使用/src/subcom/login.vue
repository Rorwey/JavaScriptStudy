<template>
  <div>
    <h3>这是Account的登录子组件</h3>
  </div>
</template>

<script>
</script>


<style scoped>
/* 样式的 scoped 是通过 CSS 的属性选择器实现的 */
div {
  color: red;
}
</style>
